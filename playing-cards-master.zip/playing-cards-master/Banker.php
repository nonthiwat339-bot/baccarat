<?php
/**
 * User: delboy1978uk
 * Date: 21/10/2013
 * Time: 23:55
 */

namespace PlayingCards;


class Banker extends Player
{
    public function __construct()
    {
        parent::__construct(0);
    }
}